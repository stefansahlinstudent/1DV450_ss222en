class Status < ActiveRecord::Base
	has_many :minigoal
	
end
