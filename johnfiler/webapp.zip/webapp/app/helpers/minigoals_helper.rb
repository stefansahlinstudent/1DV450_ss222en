module MinigoalsHelper
end
