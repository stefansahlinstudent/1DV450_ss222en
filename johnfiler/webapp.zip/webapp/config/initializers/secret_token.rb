# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Webapp::Application.config.secret_token = '3ca240f5cb620b73905a990314bc5ac49bd32359421d16f3723f7e7f809878955b1965c1dca2564dcb943784eaa3c56a12f0668bd54df344d0ff7af18aa268e9'
