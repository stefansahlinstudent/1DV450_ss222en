require 'test_helper'

class FirstHelperTest < ActionView::TestCase
end
