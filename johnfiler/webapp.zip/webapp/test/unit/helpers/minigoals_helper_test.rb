require 'test_helper'

class MinigoalsHelperTest < ActionView::TestCase
end
