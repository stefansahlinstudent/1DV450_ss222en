require 'test_helper'

class ErrorsHelperTest < ActionView::TestCase
end
