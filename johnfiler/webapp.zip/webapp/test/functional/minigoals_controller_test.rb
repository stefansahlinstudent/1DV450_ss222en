require 'test_helper'

class MinigoalsControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
