from myapp.models import Project, Status, Minigoal
from django.contrib import admin

admin.site.register(Project)
admin.site.register(Minigoal)
admin.site.register(Status)